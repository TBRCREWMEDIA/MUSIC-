Free to use for any purpose but not for resale, feel free to share this on your youtube website/blog. 
Please link to our website for the orogonal download link "www.producersbuzz.com/downloadurlhere". 
If you use this vocal preset on your recording please give credit to www.producersbuzz.com for the vocal preset. 

This vocal preset was created by ProducersBuzz

Check out www.producersbuzz.com for more vocal presets, downloads, drum kits, soundfonts, vst plugins and much more. 
----------------------------------------------------------------------------------------------------------------------
(C) 2020 ProducersBuzz