Free to use for any purpose but not for resale, feel free to share this on your youtube website/blog. 
Please link to our website for the original download link "www.tbrcrewmmp.com". 
If you use this vocal preset on your recording please give credit to www.tbrcrewmmp.com for the vocal preset. 

This vocal preset was created by TBR CREW MEDIA

Check out www.tbrcrewmmp.com for more vocal presets, downloads, drum kits, soundfonts, vst plugins and much more. 
----------------------------------------------------------------------------------------------------------------------
Copyright © 2021 TBR CREW MEDIA